import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { login } from '../api/client';
import { useAuth } from '../hooks/useAuth';

const LoginPage: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { setTokens } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!username || !password) {
      setError('请输入用户名和密码');
      return;
    }
    try {
      setLoading(true);
      const resp = await login(username, password);
      setTokens(resp.access_token, resp.refresh_token);
      navigate('/desktops', { replace: true });
    } catch (err: any) {
      setError(err?.message || '登录失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-neutral-900/70 border border-neutral-800 rounded-2xl p-8 shadow-xl">
        <h1 className="text-2xl font-semibold mb-2">Pocket Coder 登录</h1>
        <p className="text-sm text-neutral-400 mb-6">使用账号密码登录，手机端将显示已绑定的电脑。</p>

        <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
          <label className="flex flex-col gap-2 text-sm">
            <span className="text-neutral-300">用户名</span>
            <input
              className="bg-neutral-800 border border-neutral-700 rounded-lg px-3 py-2 focus:outline-none focus:border-neutral-500"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="your-name"
              autoComplete="username"
            />
          </label>

          <label className="flex flex-col gap-2 text-sm">
            <span className="text-neutral-300">密码</span>
            <input
              type="password"
              className="bg-neutral-800 border border-neutral-700 rounded-lg px-3 py-2 focus:outline-none focus:border-neutral-500"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
            />
          </label>

          {error && <div className="text-sm text-rose-400">{error}</div>}

          <button
            type="submit"
            disabled={loading}
            className="h-11 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 font-semibold"
          >
            {loading ? '登录中...' : '登录并查看我的电脑'}
          </button>

          <div className="text-sm text-neutral-400 text-center">
            还没有账号？<Link className="text-emerald-400 hover:text-emerald-300" to="/register">去注册</Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
