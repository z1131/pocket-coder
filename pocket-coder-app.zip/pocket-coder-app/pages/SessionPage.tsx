import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { usePocketWS } from '../hooks/usePocketWS';
import { ConnectionStatus, Message, PocketEvent } from '../types';
import StreamList from '../components/StreamList';
import ActionBar from '../components/ActionBar';
import { ArrowLeft } from 'lucide-react';

const SessionPage: React.FC = () => {
  const { desktopId } = useParams<{ desktopId: string }>();
  const navigate = useNavigate();
  const { accessToken } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [isThinking, setIsThinking] = useState(false);

  const handleEvent = useCallback((evt: PocketEvent) => {
    switch (evt.kind) {
      case 'session-create':
        setSessionId(evt.sessionId);
        setMessages((prev) => [...prev, {
          id: `session-${evt.sessionId}`,
          type: 'info',
          content: `会话已创建 #${evt.sessionId}${evt.workingDir ? ` · ${evt.workingDir}` : ''}`,
          timestamp: Date.now(),
        }]);
        break;
      case 'agent-status':
        if (evt.status === 'running') setIsThinking(true);
        if (evt.status === 'idle') setIsThinking(false);
        break;
      case 'agent-stream':
        setMessages((prev) => {
          if (prev.length === 0) {
            return prev;
          }
          const last = prev[prev.length - 1];
          if (last.type === 'log' && typeof last.content === 'string') {
            const merged = { ...last, content: `${last.content}${evt.delta}` } as Message;
            return [...prev.slice(0, -1), merged];
          }
          return [...prev, {
            id: `stream-${evt.sessionId}-${Date.now()}`,
            type: 'log',
            content: evt.delta,
            timestamp: Date.now(),
          }];
        });
        break;
      case 'agent-response':
        setMessages((prev) => [...prev, {
          id: `resp-${evt.sessionId}-${Date.now()}`,
          type: 'success',
          content: evt.content,
          timestamp: Date.now(),
        }]);
        setIsThinking(false);
        break;
      case 'error':
        setMessages((prev) => [...prev, {
          id: `err-${evt.code}-${Date.now()}`,
          type: 'error',
          content: `${evt.message} (code ${evt.code})`,
          timestamp: Date.now(),
        }]);
        setIsThinking(false);
        break;
      default:
        break;
    }
  }, []);

  const { status: wsStatus, sendUserMessage } = usePocketWS({ token: accessToken, onEvent: handleEvent });

  const handleSend = useCallback((text: string) => {
    if (!desktopId) return;
    const did = Number(desktopId);
    const messageId = sendUserMessage({ desktopId: did, content: text, sessionId: sessionId || undefined });
    setMessages((prev) => [...prev, {
      id: messageId,
      type: 'prompt',
      content: text,
      timestamp: Date.now(),
    }]);
    setIsThinking(true);
  }, [desktopId, sendUserMessage, sessionId]);

  const statusText = useMemo(() => {
    if (wsStatus === ConnectionStatus.CONNECTING) return '连接中';
    if (wsStatus === ConnectionStatus.BUSY) return '忙碌';
    if (wsStatus === ConnectionStatus.CONNECTED) return '已连接';
    return '未连接';
  }, [wsStatus]);

  useEffect(() => {
    if (!desktopId || !accessToken) {
      navigate('/desktops', { replace: true });
    }
  }, [desktopId, accessToken, navigate]);

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <header className="px-4 py-3 border-b border-neutral-900 flex items-center gap-3">
        <button
          onClick={() => navigate('/desktops')}
          className="p-2 rounded-lg border border-neutral-800 bg-neutral-900 hover:bg-neutral-800"
        >
          <ArrowLeft size={16} />
        </button>
        <div className="flex flex-col">
          <span className="text-sm text-neutral-500">Desktop #{desktopId}</span>
          <span className="text-base font-semibold">会话</span>
        </div>
        <div className="ml-auto text-xs text-neutral-400">WS：{statusText}</div>
      </header>

      <StreamList messages={messages} isThinking={isThinking} />
      <ActionBar activePrompt={null} onRespond={handleSend} status={wsStatus} />
    </div>
  );
};

export default SessionPage;
