import React, { useState, useEffect, useCallback, useRef } from 'react';
import Header from './components/Header';
import StreamList from './components/StreamList';
import ActionBar from './components/ActionBar';
import { Message, ConnectionStatus, PromptAction, DiffContent } from './types';

// --- MOCK DATA SCENARIOS ---

const SCENARIO_INTRO = [
  { type: 'log', content: 'Authenticating with Claude Code Agent...' },
  { type: 'success', content: 'Connection established to workstation "Main-Rig-01".' },
  { type: 'log', content: 'Syncing project state...' },
  { type: 'log', content: 'Ready. Waiting for commands.' }
];

const SCENARIO_REFACTOR = {
  steps: [
    { type: 'log', content: 'Analyzing src/utils/api.ts for deprecated patterns...' },
    { type: 'log', content: 'Found 1 instance of synchronous fetch.' },
    { type: 'diff', content: {
        file: 'src/utils/api.ts',
        language: 'typescript',
        lines: [
          '@@ -12,7 +12,7 @@',
          ' export const fetchData = async (id: string) => {',
          '-  const response = await fetch(`/api/v1/data/${id}`);',
          '+  const response = await client.get(`/v2/items/${id}`);',
          '   if (!response.ok) {',
          '-    throw new Error("Network response was not ok");',
          '+    throw new Error(`API Error: ${response.statusText}`);',
          '   }',
          '   return response.json();',
        ]
      } as DiffContent
    },
    { 
      type: 'prompt', 
      content: 'I have updated the fetch logic to use the new client. Shall I apply these changes?', 
      actions: [
        { label: 'Approve', value: 'approve_refactor', type: 'primary' },
        { label: 'Reject', value: 'reject', type: 'danger' }
      ]
    }
  ]
};

const SCENARIO_TEST_FAIL = {
  steps: [
    { type: 'log', content: 'Running test suite "Core/Auth"...' },
    { type: 'log', content: ' PASS  src/auth/login.test.ts' },
    { type: 'error', content: ' FAIL  src/auth/session.test.ts' },
    { type: 'log', content: 'ReferenceError: session is not defined' },
    { type: 'diff', content: {
        file: 'src/auth/session.ts',
        language: 'typescript',
        lines: [
          '@@ -20,2 +20,3 @@',
          ' export function getSession() {',
          '+  const session = localStorage.getItem("session");',
          '   if (!session) return null;',
          '   return JSON.parse(session);',
        ]
      } as DiffContent 
    },
    { 
      type: 'prompt', 
      content: 'It looks like the variable was missing. I added the definition. Run tests again?', 
      actions: [
        { label: 'Fix & Run', value: 'approve_fix', type: 'primary' },
        { label: 'Skip', value: 'reject', type: 'neutral' }
      ]
    }
  ]
};

const SCENARIO_DEPLOY = {
  steps: [
    { type: 'log', content: 'Building production bundle...' },
    { type: 'log', content: 'Optimizing assets (24/24)...' },
    { type: 'success', content: 'Build successful (4.2s).' },
    { type: 'log', content: 'Deploying to Vercel (Production)...' },
    { type: 'prompt', content: 'Production deployment ready. Promote to live?', actions: [
        { label: 'Promote', value: 'approve_deploy', type: 'primary' },
        { label: 'Abort', value: 'reject', type: 'danger' }
    ]}
  ]
};

const App: React.FC = () => {
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.CONNECTING);
  const [messages, setMessages] = useState<Message[]>([]);
  const [activePrompt, setActivePrompt] = useState<{ id: string, actions?: PromptAction[] } | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  
  // Use a ref to ensure we don't have race conditions with the simulation queue
  const messageQueueRef = useRef<Message[]>([]);

  // --- ENGINE ---

  const pushMessage = (msg: Partial<Message>) => {
    const newMessage = { 
        id: Date.now().toString() + Math.random(), 
        timestamp: Date.now(),
        ...msg 
    } as Message;
    
    setMessages(prev => [...prev, newMessage]);
    
    if (msg.type === 'prompt') {
      setActivePrompt({ id: newMessage.id, actions: msg.actions });
      setIsThinking(false);
      setStatus(ConnectionStatus.CONNECTED);
    }
  };

  const playScenario = (steps: any[], delayBase = 800) => {
    setIsThinking(true);
    setStatus(ConnectionStatus.BUSY);
    
    let cumulativeDelay = 0;

    steps.forEach((step, index) => {
      // Vary delay based on complexity
      const delay = delayBase + (Math.random() * 500); 
      cumulativeDelay += delay;

      setTimeout(() => {
        pushMessage(step);
        // If it's the last step and NOT a prompt, stop thinking
        if (index === steps.length - 1 && step.type !== 'prompt') {
            setIsThinking(false);
            setStatus(ConnectionStatus.CONNECTED);
        }
      }, cumulativeDelay);
    });
  };

  // --- INITIALIZATION ---
  useEffect(() => {
    setTimeout(() => {
        setStatus(ConnectionStatus.CONNECTED);
        playScenario(SCENARIO_INTRO, 600);
        
        // Auto-start the refactor scenario after intro
        setTimeout(() => {
             pushMessage({ type: 'log', content: 'Received trigger: Auto-Review started.' });
             playScenario(SCENARIO_REFACTOR.steps, 1000);
        }, 5000);

    }, 1000);
  }, []);

  // --- HANDLER ---

  const handleUserResponse = useCallback((value: string) => {
    const val = value.toLowerCase();

    // 1. Clear Active Prompt
    setActivePrompt(null);

    // 2. Log User Action
    pushMessage({ type: 'prompt', content: `> ${value}` }); // Using prompt style for user input visual
    
    setIsThinking(true);
    setStatus(ConnectionStatus.BUSY);

    // 3. Logic Router
    setTimeout(() => {
        // --- PROMPT RESPONSES ---
        if (val.includes('approve_refactor')) {
            playScenario([
                { type: 'log', content: 'Applying patch...' },
                { type: 'success', content: 'Refactor applied successfully.' },
                { type: 'log', content: 'Waiting for next task...' }
            ]);
            return;
        }
        if (val.includes('approve_fix')) {
            playScenario([
                { type: 'log', content: 'Patch applied. Re-running tests...' },
                { type: 'success', content: 'PASS src/auth/session.test.ts (14ms)' },
                { type: 'success', content: 'All tests passed.' }
            ]);
            return;
        }
        if (val.includes('approve_deploy')) {
             playScenario([
                { type: 'log', content: 'Promoting build...' },
                { type: 'success', content: 'Deployment Complete: https://pocket-coder.app' }
            ]);
            return;
        }
        if (val.includes('reject')) {
            playScenario([
                { type: 'error', content: 'Action cancelled by user.' },
                { type: 'log', content: 'Reverting workspace state...' }
            ]);
            return;
        }

        // --- FREE TEXT COMMANDS ---
        
        if (val.includes('test')) {
            playScenario(SCENARIO_TEST_FAIL.steps);
            return;
        }

        if (val.includes('deploy')) {
            playScenario(SCENARIO_DEPLOY.steps);
            return;
        }

        if (val.includes('refactor') || val.includes('fix')) {
             playScenario(SCENARIO_REFACTOR.steps);
             return;
        }

        if (val.includes('clear')) {
            setMessages([]);
            setIsThinking(false);
            setStatus(ConnectionStatus.CONNECTED);
            pushMessage({ type: 'info', content: 'Console cleared.' });
            return;
        }

        // Default / Fallback
        playScenario([
            { type: 'log', content: `Processing command: "${val}"...` },
            { type: 'log', content: 'Running heuristic analysis...' },
            { type: 'info', content: 'No specific tasks found for this query. Try "test", "deploy", or "refactor".' }
        ]);

    }, 1000);

  }, []);

  return (
    <div className="flex flex-col h-screen bg-black text-white font-sans selection:bg-neutral-700">
      <Header status={status} machineName="Main-Rig-01" />
      
      <main className="flex-1 flex flex-col relative max-w-2xl mx-auto w-full border-x border-neutral-900/50">
        <StreamList messages={messages} isThinking={isThinking} />
        
        <div className="pointer-events-none fixed bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black via-black/80 to-transparent z-30" />
        
        <ActionBar 
            activePrompt={activePrompt} 
            onRespond={handleUserResponse} 
            status={status}
        />
      </main>
    </div>
  );
};

export default App;