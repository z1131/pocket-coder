export type MessageType = 'log' | 'diff' | 'prompt' | 'success' | 'error' | 'info';

export interface DiffContent {
  file: string;
  language: string;
  lines: string[];
}

export interface PromptAction {
  label: string;
  value: string;
  type: 'primary' | 'danger' | 'neutral';
}

export interface Message {
  id: string;
  type: MessageType;
  content: string | DiffContent;
  timestamp: number;
  // If type is prompt, these populate the UI buttons
  actions?: PromptAction[]; 
}

export enum ConnectionStatus {
  CONNECTING = 'CONNECTING',
  CONNECTED = 'CONNECTED',
  DISCONNECTED = 'DISCONNECTED',
  BUSY = 'BUSY'
}